package Model;//------------------------------------------------

import defult.ConnectDB;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class ModelAdmin {

    private static String accountId;
    private ArrayList<Integer> bookId = new ArrayList<>();//booking
    private ArrayList<Integer> memberId = new ArrayList<>();//member
    private ArrayList<String> userName = new ArrayList<>();//member
    private ArrayList<Integer> roomNo = new ArrayList<>();//room
    private ArrayList<String> roomType = new ArrayList<>();//room    
    private ArrayList<String> bookDate = new ArrayList<>();//booking
    private ArrayList<String> payDate = new ArrayList<>();//booking
    private ArrayList<String> roomStatus = new ArrayList<>();//booking

    public static String getAccountId() {
        return accountId;
    }

    public static void setAccountId(String accountId) {
        ModelAdmin.accountId = accountId;
    }

    public ArrayList<Integer> getBookId() {
        return bookId;
    }

    public void setBookId(ArrayList<Integer> bookId) {
        this.bookId = bookId;
    }

    public ArrayList<Integer> getMemberId() {
        return memberId;
    }

    public void setMemberId(ArrayList<Integer> memberId) {
        this.memberId = memberId;
    }

    public ArrayList<String> getUserName() {
        return userName;
    }

    public void setUserName(ArrayList<String> userName) {
        this.userName = userName;
    }

    public ArrayList<Integer> getRoomNo() {
        return roomNo;
    }

    public void setRoomNo(ArrayList<Integer> roomNo) {
        this.roomNo = roomNo;
    }

    public ArrayList<String> getRoomType() {
        return roomType;
    }

    public void setRoomType(ArrayList<String> roomType) {
        this.roomType = roomType;
    }

    public ArrayList<String> getBookDate() {
        return bookDate;
    }

    public void setBookDate(ArrayList<String> bookDate) {
        this.bookDate = bookDate;
    }

    public ArrayList<String> getPayDate() {
        return payDate;
    }

    public void setPayDate(ArrayList<String> payDate) {
        this.payDate = payDate;
    }

    public ArrayList<String> getRoomStatus() {
        return roomStatus;
    }

    public void setRoomStatus(ArrayList<String> roomStatus) {
        this.roomStatus = roomStatus;
    }

    public void selectBook() { // selectProblem
        try {
            String sql = "select * from Booking";
            PreparedStatement ps = ConnectDB.ConnectDBs().prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            String status = "select * from Rooms";
            PreparedStatement p = ConnectDB.ConnectDBs().prepareStatement(status);
            ResultSet r = p.executeQuery();
            while (rs.next()) {
                bookId.add(rs.getInt("bookId"));//.add เพิ่มช่อง + เอาข้อมูลในวงเล็บใส่ลงไปในช่อง
                memberId.add(rs.getInt("memberId"));
                
                bookDate.add(rs.getString("bookDate"));
                payDate.add(rs.getString("payDate"));
                
                /*String sqlLocation = "select * from location_outdoor where locationId = '"+rs.getInt("location_outdoor_locationId")+"'";
                ResultSet rs2 = ConnectDB.ConnectDBs().createStatement().executeQuery(sqlLocation);
                if(rs2.next()){
                    locationName.add(rs2.getString("locationName"));
                }*/
                //roomStatus.add(r.getString("roomStatus"));
            }
            while(r.next()){
               roomNo.add(r.getInt("roomNo")); 
               roomType.add(r.getString("roomType"));
               roomStatus.add(r.getString("roomStatus"));
            }


            rs.close();
            ps.close();
            r.close();
            p.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public String memberName(int memberId) {//memberNameAndSur
        String memberName = "";
        try {
            String sql1 = "select * from Member where memberId = '" + memberId + "'";
            PreparedStatement ps = ConnectDB.ConnectDBs().prepareStatement(sql1);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                memberName = rs.getString("memberName");
                String sql2 = "select * from Member where memberId = '" + memberId + "'";
                PreparedStatement ps2 = ConnectDB.ConnectDBs().prepareStatement(sql2);
                ResultSet rs2 = ps2.executeQuery();
                if (rs2.next()) {
                    memberName = rs2.getString("fname") + "  " + rs2.getString("lname");
                }
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return memberName;
    }

    public String roomType(int bookId) {//detailDisplay
        String roomType = "";
        try {
            String sql = "select * from Booking where bookId = '" + bookId + "'";
            PreparedStatement ps = ConnectDB.ConnectDBs().prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                roomType = rs.getString("roomType");
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return roomType;
    }

    public String dateDisplay(int bookId) {
        String date = "";
        try {
            String sql = "select * from Booking where bookId = '" + bookId + "'";
            PreparedStatement ps = ConnectDB.ConnectDBs().prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                date = rs.getString("bookDate");
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return date;
    }

    /*public String roomStatus(int roomNo){
        String status ="";
        try{
            String sql = "select * from problem_outdoor where problemId = '" + roomNo+"'";
            PreparedStatement ps = ConnectDB.ConnectDBs().prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            if(rs.next()){
                switch(rs.getInt("category_outdoor_categoryId")){
                    case 1 : status = "ระบบน้ำ";break;
                    case 2 : status = "ระบบไฟฟ้า";break;
                    case 3 : status = "อื่นๆ";break;
                }
            }
        }catch(Exception e){
            System.out.println(e);
        }
        return status;
    } */
    public void deleteData(String bookId) {
        try {
            String sql = "delete from Booking where bookId = '" + bookId + "'"; //ลบปัญหา
            ConnectDB.ConnectDBs().createStatement().execute(sql);
            System.out.println("ลบข้อมูล");
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    public void updateStatus(String roomId, String roomStatus) {
        try {
            String sql = "update Rooms set roomStatus = '" + roomStatus + "' where roomId = '" + roomId + "'";
            ConnectDB.ConnectDBs().createStatement().execute(sql);
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    public static void main(String[] args) {
        ModelAdmin m = new ModelAdmin();
        ConnectDB.ConnectDBs();
        m.selectBook();
        System.out.println(m.getBookId());
        System.out.println(m.getRoomType());
        System.out.println(m.getRoomNo());
        System.out.println(m.getRoomStatus());
        
//        m.Picture(1);
    }

}
