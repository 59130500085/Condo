/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;
//select username +insert roomtype + roomfloor + roomno

import defult.ConnectDB;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

public class ModelBooking {
    private static String accountId;
    public ArrayList<Integer> roomId = new ArrayList<>();//ลำดับห้อง
    public ArrayList<Integer> roomNo = new ArrayList<>();//หมายเลขห้อง
    public ArrayList<Integer> roomFloor = new ArrayList<>();//หมายเลขชั้น
    public ArrayList<String> userName = new ArrayList<>();
    public ArrayList<String> roomType = new ArrayList<>();//ประเภทห้อง

    public ModelBooking() {
    }

    public ModelBooking(String a,int b,int c) {
        roomType.add(a);
        roomFloor.add(b);
        roomNo.add(c);
    }
    
    public static String getAccountId() {
        return accountId;
    }

    public static void setAccountId(String accountId) {
        ModelBooking.accountId = accountId;
    }

    public ArrayList<Integer> getRoomId() {
        return roomId;
    }

    public void setRoomId(ArrayList<Integer> roomId) {
        this.roomId = roomId;
    }

    public ArrayList<Integer> getRoomNo() {
        return roomNo;
    }

    public void setRoomNo(ArrayList<Integer> roomNo) {
        this.roomNo = roomNo;
    }

    public ArrayList<Integer> getRoomfloor() {
        return roomFloor;
    }

    public void setRoomfloor(ArrayList<Integer> roomfloor) {
        this.roomFloor = roomfloor;
    }

    public ArrayList<String> getUserName() {
        return userName;
    }

    public void setUserName(ArrayList<String> userName) {
        this.userName = userName;
    }

    public ArrayList<String> getRoomtype() {
        return roomType;
    }

    public void setRoomtype(ArrayList<String> roomtype) {
        this.roomType = roomtype;
    }
    public void ModelBooking() {
        
    }
    
    public String setUsername(String name){
        String userName ="";
        try{
            String sql = "select * from Member = '" + name+"'";
            PreparedStatement ps = ConnectDB.ConnectDBs().prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            if(rs.next()){
                userName = rs.getString("username");
            }
        }catch(Exception e){
            System.out.println(e);
        }
        return userName;
    }
    public void insertDetail(){//insert roomtype + roomfloor + roomno
        try{
            String sql = "insert into Rooms "
                    + " values ("+roomNo+","
                    +"'"+roomFloor+"'"+","
                    +"'"+roomType+"'"+","+")";
            ConnectDB.ConnectDBs().createStatement().executeUpdate(sql);
        }catch(Exception e){
            System.out.println(e);
        }
    }
    
    public void updateDetail(String roomType,int roomFloor,int roomNo) {
        try {
            String sql1 = "update Rooms set roomType = '" + roomType + "' where roomId = '" + roomId + "'";
            String sql2 = "update Rooms set roomFloor = '" + roomFloor + "' where roomId = '" + roomId + "'";
            String sql3 = "update Rooms set roomNo = '" + roomNo + "' where roomId = '" + roomId + "'";
            ConnectDB.ConnectDBs().createStatement().executeUpdate(sql1);
            ConnectDB.ConnectDBs().createStatement().executeUpdate(sql2);
            ConnectDB.ConnectDBs().createStatement().executeUpdate(sql3);
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
    
}
