/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;
//select Cash >> price + insert all Credit >> select price

import defult.ConnectDB;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

public class ModelPayment {
    private static String accountId;
    private ArrayList<Integer> priceBook = new ArrayList<>();//เงินการจอง
    private ArrayList<Integer> creditNumber = new ArrayList<>();//หมายเลขบัตร
    private ArrayList<Integer> cvvNum = new ArrayList<>();//หมายเลขในบัตร
    private ArrayList<String> creditfName = new ArrayList<>();
    private ArrayList<String> creditlName = new ArrayList<>();
    private ArrayList<String> bank = new ArrayList<>();

    public static String getAccountId() {
        return accountId;
    }

    public static void setAccountId(String accountId) {
        ModelPayment.accountId = accountId;
    }


    public ArrayList<Integer> getPrice() {
        return priceBook;
    }

    public void setPrice(ArrayList<Integer> price) {
        this.priceBook= price;
    }

    public ArrayList<Integer> getCreditNumber() {
        return creditNumber;
    }

    public void setCreditNumber(ArrayList<Integer> creditNumber) {
        this.creditNumber = creditNumber;
    }

    public ArrayList<Integer> getCvvNum() {
        return cvvNum;
    }

    public void setCvvNum(ArrayList<Integer> cvvNum) {
        this.cvvNum = cvvNum;
    }

    public ArrayList<String> getCreditfName() {
        return creditfName;
    }

    public void setCreditfName(ArrayList<String> creditfName) {
        this.creditfName = creditfName;
    }

    public ArrayList<String> getCreditlName() {
        return creditlName;
    }

    public void setCreditlName(ArrayList<String> creditlName) {
        this.creditlName = creditlName;
    }

    public ArrayList<String> getBank() {
        return bank;
    }

    public void setBank(ArrayList<String> bank) {
        this.bank = bank;
    }
    public void ModelPayment(){
        
    } 
    //select Cash >> price + insert all Credit >> select price
    public void insertCredit(){//insert roomtype + roomfloor + roomno
        try{
            String sql = "insert into Credit "
                    + " values ("+creditNumber+","
                    +"'"+cvvNum+"'"+","
                    +"'"+creditfName+"'"+","
                    +"'"+creditlName+"'"+","
                    +"'"+bank+"'"+","                  
                    +"'"+accountId+"'"+")";
            ConnectDB.ConnectDBs().createStatement().executeUpdate(sql);
        }catch(Exception e){
            System.out.println(e);
        }
    }
    public int setPrice(int money){
        int priceBook =0;
        try{
            String sql = "select * from Booking = '" + money+"'";
            PreparedStatement ps = ConnectDB.ConnectDBs().prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            if(rs.next()){
                priceBook = rs.getInt("priceBook");
            }
        }catch(Exception e){
            System.out.println(e);
        }
        return priceBook;
    }
}
