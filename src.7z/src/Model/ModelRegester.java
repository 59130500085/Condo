//------------------------------------------------
package Model;
import java.sql.*;
import defult.ConnectDB;
import java.sql.*;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

public class ModelRegester {
    private static String accountId;
    private static int memberId;
    //private static int bookid;
    private String name;
    private String surname;
    private String sex;
    private String tel;
    private String birthday;
    private String email;
    private String address;
    private String province;
    private String username;
    private String password;
    private String idCard;
    private String date;
    private static final String user = "user";
    public ModelRegester() {}

    public ModelRegester(String name, String surname, String sex, String tel, 
                       String birthday, String email, String address,String province, 
                       String username, String password, String idCard) {
        this.name = name;
        this.surname = surname;
        this.sex = sex;
        this.tel = tel;
        this.birthday = birthday;
        this.email = email;
        this.address = address;
        this.province = province;
        this.username = username;
        this.password = password;
        this.idCard = idCard;
    }

    public static int getMemberId() {
        return memberId;
    }

    public static void setMemberId(int memberId) {
        ModelRegester.memberId = memberId;
    }

    /*public static int getBookid() {
        return bookid;
    }

    public static void setBookid(int bookid) {
        ModelRegester.bookid = bookid;
    }*/

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public String getTel() {
        return tel;
    }

    public void setTel(String tel) {
        this.tel = tel;
    }

    public String getBirthday() {
        return birthday;
    }

    public void setBirthday(String birthday) {
        this.birthday = birthday;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getProvince() {
        return province;
    }

    public void setProvince(String province) {
        this.province = province;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getIdCard() {
        return idCard;
    }

    public void setIdCard(String idCard) {
        this.idCard = idCard;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }
    
    public static void setAccountId(String id){
        accountId = id;
    }
        
    public void setDate() {
        LocalDateTime ld = LocalDateTime.now();
        date = ld.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
    }
    
    public static void setMemberId(){
        try{
            String sql = "select * from Member";
            PreparedStatement ps = ConnectDB.ConnectDBs().prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while(rs.next()){
                memberId = rs.getInt("memberId")+1;
            }
        }catch(Exception e){
            System.out.println(e);
        }
    }
    
    public static void excuteID(){
        setMemberId();//อันล่าสุด
    }
    public void insertMember(){
        try{
            String sql = "insert into Member "
                    + "(memberId,userName,"
                    + "password,fname,lname,"
                    + "sex,address,province,telNo,"
                    + "idCard,birthDate,email,memberType)"
                    + " values ("+memberId+1+","
                    +"'"+username+"'"+","
                    +"'"+password+"'"+","
                    +"'"+name+"'"+","
                    +"'"+surname+"'"+","
                    +"'"+sex+"'"+","
                    +"'"+address+"'"+","
                    +"'"+province+"'"+","
                    +"'"+tel+"'"+","
                    +"'"+idCard+"'"+","
                    +"'"+birthday+"'"+","
                    +"'"+email+"'"+","
                    +"'"+user+"'"+")";
            ConnectDB.ConnectDBs().createStatement().executeUpdate(sql);
            //ResultSet rs = ps.executeQuery();
            System.out.println("insert already");
        }catch(Exception e){
            System.out.println(e);
        }
    }
    
    public void formToDB(){
        setDate();
        excuteID();
        insertMember();
    }
   
}
