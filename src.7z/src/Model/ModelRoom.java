/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.util.ArrayList;
import java.util.Date;

public class ModelRoom {
    private static String accountId;
    public int roomNo;//หมายเลขห้อง   
    public String userName;
    public String roomStatus;//สถานะห้อง
    public boolean credit;
    public String bank;
    public String fname;
    public String lname;
    public String creditNumber;
    public int priceBook;
    public Date bookDate;
//    public int memberid;
//    public String password;

//    public String sex;
//    public String address;
//    public String telno;
//    public String idCard;
//    public String birthDate;
//    public String email;
//    public String memberType;
//    public int bookId;
//    public String bookDate;
//    public String payDate;
//    public String payment;
//    public int priceBook;
//    public int memberId;
//    public
         
}
