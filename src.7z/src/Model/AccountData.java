package Model;

import java.sql.*;
import defult.ConnectDB;

public class AccountData {
    private String name;
    private String surname;
    private String email;
    private int type;
    
    public AccountData(){
    }
    
    public void setAccountDetail(String id){
        try{
            String sql = "select * from Member where memberId like "+id;
            ResultSet rs = ConnectDB.ConnectDBs().prepareStatement(sql).executeQuery();
            if(rs.next()){
                name = rs.getString("fname");
                surname = rs.getString("lname");
                //email = rs.getString("email");
            }
        }
        catch(Exception e){}    
    }

    public String getName() {
        return name;
    }

    public String getSurname() {
        return surname;
    }

    public String getEmail() {
        return email;
    }

    public int getType() {
        return type;
    }
    
//    
//    public static void main(String[] args){
//        ConnectDB.ConnectDaB();
//        AccountData ad = new AccountData();
//        ad.setAccountDetail("59130500090");
//        System.out.println(ad.getName());
//        System.out.println(ad.getSurname());
//        System.out.println(ad.getEmail());
//        System.out.println(ad.getType());
//    }
}
