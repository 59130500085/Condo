package Model;//------------------------------

import defult.ConnectDB;
import java.sql.*;
import javax.swing.JOptionPane;

public class ModelLogIn {

    private String id;
    private String password;

    public ModelLogIn() {
        check();
    }

    public ModelLogIn(String a, String b) {
        id = a;
        password = b;
    }

    public void setId(String id) {
        this.id = id;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public byte check() {//check user , check admin by password
        byte member = 99;//สมมติว่าไม่มีuserใดในระบบ
        System.out.println(id + password);
        try {
            System.out.println(id);
            String sql = "select * from Member where username = " + "\'" + id + "\'";
            System.out.println(sql);
            PreparedStatement pt = ConnectDB.ConnectDBs().prepareStatement(sql);
            ResultSet rs = pt.executeQuery();
            rs.next();//next เพื่อหา row แต่ถ้าไม่เจอก็เป็น null

            
            if (password.equals(rs.getString("password"))) {//user เข้าใช้งาน
                //System.out.println("login success");
                if("user".equals(rs.getString("memberType"))){
                    //System.out.println(rs.getString("password") + "\n" + rs.getString("memberType"));
                    ModelRegester.setAccountId(rs.getString("memberId"));
                    member = 1;//check case gui 
                }
                else{
                    //System.out.println("login fail");
                    //System.out.println(rs.getString("password") + "\n" + rs.getString("memberType"));
                    ModelAdmin.setAccountId(rs.getString("memberId"));
                    member = 2;
                }
                //ModelList.setAccountId(rs.getString("memberId"));
                
//            } else if (password.equals(rs.getString("password")) && rs.getString("memberType") == "admin") {//admin
//                
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "login fail");
            System.out.println(e);
        }
        return member;
    }
}
