/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;
//select username + roomno + status

import defult.ConnectDB;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import javax.swing.JOptionPane;

public class ModelStatusAllRoom {

    private static String accountId;
    public ArrayList<Integer> roomId = new ArrayList<>();
    public ArrayList<Integer> roomNo = new ArrayList<>();//หมายเลขห้อง   
    public ArrayList<String> userName = new ArrayList<>();
    public ArrayList<String> roomStatus = new ArrayList<>();//สถานะห้อง
    public ArrayList<String> roomType = new ArrayList<>();
    public ArrayList<String> roomFloor = new ArrayList<>();

    public ModelStatusAllRoom() {
    }

    public ArrayList<String> getRoomFloor() {
        return roomFloor;
    }

    public void setRoomFloor(ArrayList<String> roomFloor) {
        this.roomFloor = roomFloor;
    }

    public ArrayList<Integer> getRoomId() {
        return roomId;
    }

    public void setRoomId(ArrayList<Integer> roomId) {
        this.roomId = roomId;
    }

    public ArrayList<String> getRoomType() {
        return roomType;
    }

    public void setRoomType(ArrayList<String> roomType) {
        this.roomType = roomType;
    }

    public static String getAccountId() {
        return accountId;
    }

    public static void setAccountId(String accountId) {
        ModelStatusAllRoom.accountId = accountId;
    }

    public ArrayList<Integer> getRoomNo() {
        return roomNo;
    }

    public void setRoomNo(ArrayList<Integer> roomNo) {
        this.roomNo = roomNo;
    }

    public ArrayList<String> getUserName() {
        return userName;
    }

    public void setUserName(ArrayList<String> userName) {
        this.userName = userName;
    }

    public ArrayList<String> getRoomStatus() {
        return roomStatus;
    }

    public void setRoomStatus(ArrayList<String> roomStatus) {
        this.roomStatus = roomStatus;
    }

    public void ModelStatusAllRoom() {

    }

    //select username + roomno + status
    public void setRoomNumber(int number) {
        int roomNo = 0;
        try {
            String sql = "select * from Rooms = '" + number + "'";
            PreparedStatement ps = ConnectDB.ConnectDBs().prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                roomNo = rs.getInt("roomNo");
            }
        } catch (Exception e) {
            System.out.println(e);
        }

    }

    public void setDetailStatus(String status) {
        String roomStatus = "";
        try {
            String sql = "select * from Rooms = '" + status + "'";
            PreparedStatement ps = ConnectDB.ConnectDBs().prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                roomStatus = rs.getString("roomStatus");
            }
        } catch (Exception e) {
            System.out.println(e);
        }

    }

    public void setRoomType(String type) {
        String roomType = "";
        try {
            String sql = "select * from Rooms = '" + type + "'";
            PreparedStatement ps = ConnectDB.ConnectDBs().prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                roomType = rs.getString("roomType");
            }
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public void setUsername(String name) {
        String userName = "";
        try {
            String sql = "select * from Member = '" + name + "'";
            PreparedStatement ps = ConnectDB.ConnectDBs().prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                userName = rs.getString("username");
            }
        } catch (Exception e) {
            System.out.println(e);
        }

    }

 /*public byte check() {//check roomType ของแต่ละ roomNo
        byte type = 99;
        try {
            String sql = "select * from Rooms where roomId = " + "\'" + roomId + "\'";
            System.out.println(sql);
            PreparedStatement pt = ConnectDB.ConnectDBs().prepareStatement(sql);
            ResultSet rs = pt.executeQuery();
            rs.next();//next เพื่อหา row แต่ถ้าไม่เจอก็เป็น null

            if ("1 bedroom".equals(rs.getString("roomType"))) {
                selectRoomNo();
                type = 1;//check case gui 
            } else {
                selectRoomNo();
                type = 2;
            }            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Fail");
            System.out.println(e);
        }
        return type;
    }*/
 /*public void selectRoomNo() {
        try {
            String sql = "select * from Rooms";
            PreparedStatement ps = ConnectDB.ConnectDBs().prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                roomNo.add(rs.getInt("roomNo"));//.add เพิ่มช่อง + เอาข้อมูลในวงเล็บใส่ลงไปในช่อง
                roomStatus.add(rs.getString("roomStatus"));
            }
            rs.close();
            ps.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }*/
    public int selectRoomNo() {//void
        int type = 99;
        try {
            if ("1 bedroom".equals(roomType)) {
                String sql1 = "select * from Rooms where roomType LIKE '1 bedroom'";
                PreparedStatement ps1 = ConnectDB.ConnectDBs().prepareStatement(sql1);
                ResultSet rs1 = ps1.executeQuery();
                while (rs1.next()) {
                    roomNo.add(rs1.getInt("roomNo"));//.add เพิ่มช่อง + เอาข้อมูลในวงเล็บใส่ลงไปในช่อง
                    roomStatus.add(rs1.getString("roomStatus"));
                }
                type = 1;
                rs1.close();
                ps1.close();
            } else {
                String sql2 = "select * from Rooms where roomType LIKE '2 bedroom'";
                PreparedStatement ps2 = ConnectDB.ConnectDBs().prepareStatement(sql2);
                ResultSet rs2 = ps2.executeQuery();

                while (rs2.next()) {
                    roomNo.add(rs2.getInt("roomNo"));//.add เพิ่มช่อง + เอาข้อมูลในวงเล็บใส่ลงไปในช่อง
                    roomStatus.add(rs2.getString("roomStatus"));
                }
                type = 2;
                rs2.close();
                ps2.close();
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return type;
    }
    
    public int selectRoomNo1() {//void
        int type = 99;
        try {
            
                String sql1 = "select * from Rooms";
                PreparedStatement ps1 = ConnectDB.ConnectDBs().prepareStatement(sql1);
                ResultSet rs1 = ps1.executeQuery();
                while (rs1.next()) {
                    roomNo.add(rs1.getInt("roomNo"));//.add เพิ่มช่อง + เอาข้อมูลในวงเล็บใส่ลงไปในช่อง
                    roomStatus.add(rs1.getString("roomStatus"));
                    roomType.add(rs1.getString("roomType"));
                }
                type = 1;
                rs1.close();
                ps1.close();
            

        } catch (Exception e) {
            e.printStackTrace();
        }
        return type;
    }

    public void insertDetail(){//insert roomtype + roomfloor + roomno
        try{
            String sql = "insert into Rooms "
                    + "(roomId,roomNo,"
                    + "roomFloor,roomType)"
                    + " values ("+roomId+","
                    +"'"+roomNo+"'"+","
                    +"'"+roomFloor+"'"+","
                    +"'"+roomType+"'"+")";
            ConnectDB.ConnectDBs().createStatement().execute(sql);
            updateStatus(roomId,"Book");
        }catch(Exception e){
            System.out.println(e);
        }
    }
    
    public void updateStatus(ArrayList<Integer> roomId,String roomStatus){
        try{
            String sql = "update Rooms set roomStatus = '"+roomStatus+"' where roomId = '"+roomId+"'";
            ConnectDB.ConnectDBs().createStatement().execute(sql);
        }catch(Exception e){
            System.out.println(e.getMessage());
        }
    }
    public static void main(String[] args) {
        ModelStatusAllRoom m = new ModelStatusAllRoom();
        m.selectRoomNo();
        System.out.println(m.roomNo);
        //ConnectDB.ConnectDBs();
        //System.out.println(m.selectRoomNo());
        
        //m.check();
        //System.out.println(m.getBookId());

    }
}
