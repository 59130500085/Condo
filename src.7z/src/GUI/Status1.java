/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GUI;

import GUI.Reservation;
import Model.AccountData;
import Model.ModelStatusAllRoom;
import defult.ConnectDB;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Nutt
 */
public class Status1 extends javax.swing.JFrame {

    DefaultTableModel model1;
    String username ;
    int selected;
    ModelStatusAllRoom status1 = new ModelStatusAllRoom();

    public Status1(String user) {
        username = user;
        
        initComponents();

        model1 = (DefaultTableModel) jTable1.getModel();
        jTable1.setModel(model1);
        AccountData ad1 = new AccountData();
        jTable1.setRowHeight(30);
        tableDisplay1();
    }
    
    public Status1() {
        initComponents();

        model1 = (DefaultTableModel) jTable1.getModel();
        jTable1.setModel(model1);
        AccountData ad1 = new AccountData();
        jTable1.setRowHeight(30);
        tableDisplay1();


    }

    public void tableDisplay1() { //data in table
        Object[] row = new Object[3];
        status1.selectRoomNo1();
        System.out.println(status1.roomType);
        for (int i = 0; i < status1.getRoomNo().size(); i++) {
                row[0] = status1.getRoomNo().get(i).toString();
                row[1] = status1.getRoomStatus().get(i).toString();
                row[2] = status1.getRoomType().get(i).toString();
                model1.addRow(row);
            }
        /*if (status.selectRoomNo() == 1) {
            for (int i = 0; i < status.getRoomNo().size(); i++) {
                row[0] = status.getRoomNo().get(i).toString();
                row[1] = status.getRoomStatus().get(i).toString();
                model.addRow(row);
            }
        } else{
            for (int i = 0; i < status.getRoomNo().size(); i++) {
                row[0] = status.getRoomNo().get(i).toString();
                row[1] = status.getRoomStatus().get(i).toString();
                model.addRow(row);
            }
        }*/
        /*for (int i = 0; i < status.getRoomNo().size(); i++) {
            row[0] = status.getRoomNo().get(i).toString();
            row[1] = status.getRoomStatus().get(i).toString();
            model.addRow(row);
        }*/
    }
    

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jButton1 = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(0, 51, 102));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1170, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 30, Short.MAX_VALUE)
        );

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 140, -1, 30));

        jPanel2.setBackground(new java.awt.Color(204, 255, 255));

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "RoomNo", "Status", "Room Type"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(jTable1);
        if (jTable1.getColumnModel().getColumnCount() > 0) {
            jTable1.getColumnModel().getColumn(0).setResizable(false);
            jTable1.getColumnModel().getColumn(1).setResizable(false);
            jTable1.getColumnModel().getColumn(2).setResizable(false);
        }

        jButton1.setBackground(new java.awt.Color(0, 153, 204));
        jButton1.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jButton1.setForeground(new java.awt.Color(204, 255, 255));
        jButton1.setText("Reserve");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(33, Short.MAX_VALUE)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 556, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(31, 31, 31))
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(215, 215, 215)
                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 167, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 283, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButton1)
                .addContainerGap(38, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 170, 620, 400));

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel3.setText("๊๊ User name  :");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 90, 30));
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 20, 120, 30));

        jLabel1.setBackground(new java.awt.Color(75, 128, 181));
        jLabel1.setFont(new java.awt.Font("MV Boli", 1, 70)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(153, 204, 255));
        jLabel1.setText("  Room Status");
        jLabel1.setOpaque(true);
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 620, 140));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        //status1.insertDetail();
        //status2.insertDetail();
        String table;
        String table1, table2, table3;
        model1 = (DefaultTableModel) jTable1.getModel();
        table = model1.getValueAt(jTable1.getSelectedRow(), 0).toString();
        table1 = model1.getValueAt(jTable1.getSelectedRow(), 1).toString();
        table2 = model1.getValueAt(jTable1.getSelectedRow(), 2).toString();
        username="bear";
        System.out.println(username);
        int lastbookid = 0;
        try {        
            String sql = "SELECT `bookId` FROM `Booking` order by `bookId` DESC;";
            PreparedStatement ps = ConnectDB.ConnectDBs().prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            if(rs.next())
            lastbookid = rs.getInt(1); 
        } catch (Exception e) {
            System.out.println(e);
        }
        int memid = 0;
        try {        
            String sql = "SELECT memberId FROM Member where username = '"+username+"';";
            PreparedStatement ps = ConnectDB.ConnectDBs().prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            if(rs.next())
            memid = rs.getInt(1); 
        } catch (Exception e) {
            System.out.println(e);
        }
        System.out.println(" "+memid+lastbookid);
        try {
            
            String sql = "update Rooms set roomStatus = 'Book' where roomNo = "+table+";";
            PreparedStatement ps = ConnectDB.ConnectDBs().prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            
        } catch (Exception e) {
            System.out.println(e);
        }
        int roomId =0;
        try {        
            String sql = "SELECT roomId FROM Rooms where roomNo = "+table+";";
            PreparedStatement ps = ConnectDB.ConnectDBs().prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            if(rs.next())
            roomId = rs.getInt(1); 
        } catch (Exception e) {
            System.out.println(e);
        }
        try {
            
            String sql = "insert into Booking (bookId,bookDate,memberId,priceBook,roomId) VALUES ('"+(lastbookid+1)+"','2017-11-11','"+memid+"',10000,'"+roomId+"');";
            PreparedStatement ps = ConnectDB.ConnectDBs().prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            
        } catch (Exception e) {
            System.out.println(e);
        }
        ////////////////////////////////////////////////////////////////////////
        
//        System.out.println(table+table1+table2);
//        if(){
//            model1 = (DefaultTableModel) jTable1.getModel();
//            table1 = model1.getValueAt(jTable1.getSelectedRow(), 0).toString();
//            table2 = model1.getValueAt(jTable1.getSelectedRow(), 1).toString();
//        }else{
//            model2 = (DefaultTableModel) jTable2.getModel();
//            table1 = model1.getValueAt(jTable2.getSelectedRow(), 0).toString();
//            table2 = model1.getValueAt(jTable2.getSelectedRow(), 1).toString();
//        }
//        
//        
//        
//        JButton btnOpen = new JButton("Open Form");
//        HowToPlay form = new HowToPlay();
//        form.setVisible(true);
//        dispose();// TODO add your handling code here:
    }//GEN-LAST:event_jButton1ActionPerformed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Status1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Status1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Status1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Status1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                ConnectDB.ConnectDBs();
                new Status1().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    // End of variables declaration//GEN-END:variables
}
