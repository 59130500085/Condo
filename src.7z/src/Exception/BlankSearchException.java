package Exception;
public class BlankSearchException extends Exception{
    public BlankSearchException(){
        super("กรุณาใส่ข้อความ");
    }
    public BlankSearchException(String s){
        super(s);
    }
}