package defult;//--------------------------------------------------------------------------------------------------------------

import java.sql.*;

public class ConnectDB {

    private static Connection mySqlCon;

    public static Connection ConnectDBs() {
        try {
            Class.forName("org.mariadb.jdbc.Driver");
            //String url = "jdbc:mysql://localhost:3306/kaname_db3?";
            mySqlCon = DriverManager.getConnection("jdbc:mariadb://pma.int203.phornlert.me:3306/projectcondo", "projectcondo", "projectcondo");
            System.out.println("ต่อติด");
        } catch (Exception e) {
            System.out.println("พังเจ๊ง ตู้มตู้ม");
            e.printStackTrace();
        }
        return mySqlCon;
    }

    /*public static Connection getMySqlConnect(){
        return mySqlCon;
        
    }*/
    public static void main(String[] args) throws SQLException {
        Connection con = ConnectDB.ConnectDBs();
        String sql = "select * from Member ";
        System.out.println(sql);
        PreparedStatement pt = ConnectDB.ConnectDBs().prepareStatement(sql);
        ResultSet rs = pt.executeQuery();
        if (rs.next()) {
            System.out.println(rs.getString("username"));
        }

        System.out.println("ต่อติด");
    }
}
